package com.dscode.ebicart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbicartApplicationTests {

	@Test
	void contextLoads() {
	}

}
