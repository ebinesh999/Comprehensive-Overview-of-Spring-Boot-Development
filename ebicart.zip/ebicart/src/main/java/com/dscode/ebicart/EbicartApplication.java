package com.dscode.ebicart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbicartApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbicartApplication.class, args);
	}

}
